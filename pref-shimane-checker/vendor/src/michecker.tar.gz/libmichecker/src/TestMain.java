
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import jp.netlab.michecker.VisualizeAndCheck;

public class TestMain {

  public static void main(String args[]) {
    VisualizeAndCheck vac = new VisualizeAndCheck("");

    BufferedReader br = null;
    try {
      File i = new File("./sample/sample.html");
      br = new BufferedReader(new InputStreamReader(new FileInputStream(i)));
      StringBuffer sb = new StringBuffer();
      int c;
      while ((c = br.read()) != -1) {
        sb.append((char) c);
      }
      String html = sb.toString();
      System.out.println(vac.doEvaluate(html));
    } catch (Exception e) {
       e.printStackTrace();
    }
  }
}
