package jp.netlab.michecker;
/*******************************************************************************
 * Copyright (c) 2008 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.UUID;
import java.util.Vector;

import org.eclipse.actf.model.dom.html.HTMLParserFactory;
import org.eclipse.actf.model.dom.html.IHTMLParser;
import org.eclipse.actf.model.ui.IModelService;
import org.eclipse.actf.model.ui.editor.browser.IWebBrowserACTF;
import org.eclipse.actf.util.FileUtils;
import org.eclipse.actf.util.dom.DomPrintUtil;
import org.eclipse.actf.visualization.blind.IBlindVisualizer;
import org.eclipse.actf.visualization.engines.blind.eval.EvaluationResultBlind;
import org.eclipse.actf.visualization.engines.blind.html.IVisualizeMapData;
import org.eclipse.actf.visualization.engines.blind.html.VisualizeEngine;
import org.eclipse.actf.visualization.engines.blind.html.util.HtmlErrorLogListener;
import org.eclipse.actf.visualization.eval.CheckTargetFactory;
import org.eclipse.actf.visualization.eval.EvaluationUtil;
import org.eclipse.actf.visualization.eval.IHtmlCheckTarget;
import org.eclipse.actf.visualization.eval.IHtmlChecker;
import org.eclipse.actf.visualization.eval.guideline.GuidelineHolder;
import org.eclipse.actf.visualization.eval.html.HtmlEvalUtil;
import org.eclipse.actf.visualization.eval.html.statistics.PageData;
import org.eclipse.actf.visualization.eval.problem.HighlightTargetNodeInfo;
import org.eclipse.actf.visualization.eval.problem.IProblemItem;
import org.eclipse.actf.visualization.util.html2view.Html2ViewMapData;
import org.eclipse.actf.visualization.util.html2view.Html2ViewMapMaker;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class BlindVisualizerHtml extends BlindVisualizerBase implements IBlindVisualizer {

  public static final int FRAME = 1;

  private static final String ORIG_HTML_FILE       = "original.html";
  private static final String IE_HTML_FILE         = "ie.html";
  private static final String HTML_SOURCE_FILE     = "source.html";
  private static final String MAPPED_HTML_FILE_PRE = "mapped.";

  private String orgFileName;
  private String ieFileName;
  private String sourceFileName;
  private String targetFileName;

  private IWebBrowserACTF webBrowser;

  /**
   *
   */
  public BlindVisualizerHtml(String path) {
    String tmpDirPath = "";
    if (path != null && !path.isEmpty()) {
      tmpDirPath = path;
    } else {
      tmpDirPath = "./tmp/";
    }

    File tmpDir = new File(tmpDirPath);
    super.tmpDirS = tmpDir.getAbsolutePath() + File.separator;
  }

  @Override
  public boolean setModelService(IModelService targetModel) {
    webBrowser = null;
    if (super.setModelService(targetModel)) {
      webBrowser = (IWebBrowserACTF) targetModel;
      return true;
    }
    return false;
  }

  public boolean isTarget(IModelService modelService) {
    if (null != modelService && modelService instanceof IWebBrowserACTF) {
      return true;
    }
    return false;
  }

  public int visualize() {
    GuidelineHolder.getInstance().setTargetMimeType("text/html"); //$NON-NLS-1$
    String prefix = createUUID();
    if (prefix == null) {
       return ERROR;
    }

    int ret = ERROR;
    int frameId = 0;
    checkResult = new EvaluationResultBlind();
    File orgFile     = null;
    File liveFile    = null;
    File targetFile  = null;

    orgFileName    = prefix + "." + IE_HTML_FILE;
    ieFileName     = prefix + "." + ORIG_HTML_FILE;
    sourceFileName = prefix + "." + HTML_SOURCE_FILE;
    targetFileName = prefix + "." + MAPPED_HTML_FILE_PRE + frameId + ".html";

    try {
      orgFile  = webBrowser.saveOriginalDocument(tmpDirS + orgFileName);
      liveFile = webBrowser.saveDocumentAsHTMLFile(tmpDirS + ieFileName);
       webBrowser.saveOriginalDocument(tmpDirS + sourceFileName);


      Vector<Html2ViewMapData> html2ViewMapV = new Vector<Html2ViewMapData>();
      IHTMLParser htmlParser = HTMLParserFactory.createHTMLParser();
      HtmlErrorLogListener errorLogListener = new HtmlErrorLogListener();
      htmlParser.addErrorLogListener(errorLogListener);

      boolean isIEhtml = false;
      if (EvaluationUtil.isOriginalDOM()) {
        html2ViewMapV = Html2ViewMapMaker.makeMap(orgFileName, targetFileName, tmpDirS);
        // decode miss
        if (html2ViewMapV.size() == 0) {
          isIEhtml = true;
        }
      } else {
        isIEhtml = true;
      }

      // for line<>id mapping
      // HtmlLine2Id htmlLine2Id = new HtmlLine2Id(html2ViewMapV);

      Document document;
      Document ieDom;
      Document originalDocument;
      if (isIEhtml) {
        ieDom = webBrowser.getLiveDocument();

        // TODO replace with DomByCom (need clone/write support)
        IHTMLParser tmpHtmlParser = HTMLParserFactory.createHTMLParser();
        tmpHtmlParser.parse(new FileInputStream(tmpDirS + ieFileName));
        document = tmpHtmlParser.getDocument();

        tmpHtmlParser.parse(new FileInputStream(tmpDirS + orgFileName));
        originalDocument = tmpHtmlParser.getDocument();

        targetFile = liveFile;

      } else {
        htmlParser.parse(new FileInputStream(tmpDirS + targetFileName));
        document = htmlParser.getDocument();
        originalDocument = document;
        ieDom = webBrowser.getLiveDocument();
        targetFile = orgFile;
      }

      boolean hasFrame = false;

      if (document == null) {
        return ERROR;
      } else if (hasFrameset(document, webBrowser) == true) {
        hasFrame = true;
      }

      pageData = new PageData();

      VisualizeEngine engine = new VisualizeEngine();
      engine.setBaseUrl(""); //$NON-NLS-1$
      engine.setTargetUrl(targetUrl);
      engine.setDocument(document);
      engine.setHtml2viewMapV(html2ViewMapV);
      engine.setInvisibleIdSet(new HashSet<String>());
      engine.setPageData(pageData);
      engine.visualize();

      maxReachingTime = engine.getMaxTime();

      resultDocument = engine.getResult();
      checkResult.setProblemList(engine.getProbelems());
      checkResult.setTargetUrl(targetUrl);

      if (variantFile != null) {
        variantFile.delete();
      }
      variantFile = engine.getVariantFile();
      checkResult.addAssociateFile(variantFile);

      IVisualizeMapData mapData = engine.getVisualizeMapData();

      // TODO
      checkResult.setSourceFile(new File(tmpDirS + sourceFileName));

      boolean isDBCS = true;

      HtmlEvalUtil edu = new HtmlEvalUtil(document,
          resultDocument,
          targetUrl,
          mapData.getOrig2idMap(),
          originalDocument,
          ieDom,
          pageData,
          isDBCS,
          isIEhtml);

      edu.setLiveFile(liveFile);
      edu.setSrcFile(orgFile);
      edu.setTargetFile(targetFile);

       ArrayList<IProblemItem> tmpResults = new ArrayList<IProblemItem>(1024);

      // TODO re-impl BrowserAndStyleInfo
      //
      // BrowserAndStyleInfo data =
      // webBrowser.getBrowserAndStyleInfo();
      IHtmlCheckTarget checkTarget = CheckTargetFactory.createHtmlCheckTarget(document, webBrowser.getURL(), null,edu);

      for (int i = 0; i < checkers.length; i++) {
        if (checkers[i] instanceof IHtmlChecker) {
          tmpResults.addAll(((IHtmlChecker) checkers[i])
              .checkHtml(checkTarget));
        } else if (checkers[i].isTargetFormat(webBrowser
            .getCurrentMIMEType()) && checkers[i].isEnabled()) {
          tmpResults.addAll(checkers[i].check(checkTarget));
        }
      }

      // TODO support blind biz -> visitor
      for (int i = 0; i < tmpResults.size(); i++) {
        IProblemItem tmpItem = tmpResults.get(i);
        HighlightTargetNodeInfo nodeInfo = tmpItem
        .getHighlightTargetNodeInfo();
        if (nodeInfo != null) {
          if (tmpItem.getHighlightTargetIds().length == 0) {
            tmpItem.setHighlightTargetIds(nodeInfo
                .getHighlightTargetIds(mapData.getOrig2idMap()));
          }
          if (EvaluationUtil.isOriginalDOM()) {
            tmpItem.setHighlightTargetSourceInfo(nodeInfo
                .getHighlightTargetSourceInfo(html2ViewMapV));
          }
        }
      }
      checkResult.addProblemItems(tmpResults);
      checkResult.addProblemItems(errorLogListener.getHtmlProblemVector());
      checkResult.accept(pageData);

      if (resultFile != null) {
        resultFile.delete();
      }

      resultFile = File.createTempFile("result",".html", new File(tmpDirS));

      try {
        // HtmlParserUtil.saveHtmlDocumentAsUTF8(
        // (SHDocument) resultDocument, tmpFile, resultFile);
        DomPrintUtil dpu = new DomPrintUtil(resultDocument);
        dpu.writeToFile(resultFile);

      } catch (Exception e3) {
        e3.printStackTrace();
      }

      if (hasFrame) {
        pageData.setHasFrame(true);
        ret = FRAME;
      } else if (webBrowser != null && !webBrowser.isUrlExists()) {
        // TODO
        pageData.setError(true);
        ret =  ERROR;
      }
      ret = OK;
    } catch (Exception e) {
      e.printStackTrace();
      ret = ERROR;
    } finally {
      cleanTmpfiles();
    }
    return ret;
  }

  @SuppressWarnings("nls")
  private boolean hasFrameset(Document document, IWebBrowserACTF webBrowser) {

    NodeList framesetNl = document.getElementsByTagName("frameset");

    if (framesetNl.getLength() > 0) {

      NodeList frameList = document.getElementsByTagName("frame");

      // TODO:anno
      String sFileName = "";
      //			String sFileName = BlindVizResourceUtil.getTempDirectory()
      //					+ "frameList.html";

      String base = webBrowser.getURL();

      try {
        URL baseURL = new URL(base);

        NodeList baseNL = document.getElementsByTagName("base");
        if (baseNL.getLength() > 0) {
          Element baseE = (Element) baseNL
          .item(baseNL.getLength() - 1);
          String baseUrlS = baseE.getAttribute("href");
          if (baseUrlS.length() > 0) {
            URL tmpUrl = new URL(baseURL, baseUrlS);
            base = tmpUrl.toString();
          }
        }
      } catch (Exception e) {
      }

      PrintWriter fileOutput;

      try {
        fileOutput = new PrintWriter(new OutputStreamWriter(
            new FileOutputStream(sFileName), "UTF-8"));
      } catch (IOException e) {
        // e.printStackTrace();
        // TODO
        return true;
      }

      fileOutput.write("<html>");
      // " lang=\""+lang+\">"); //use var
      fileOutput.write("<head>" + FileUtils.LINE_SEP);
      fileOutput
      .write("<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\" >"
          + FileUtils.LINE_SEP);
      fileOutput.write("<base href=\"" + base + "\"></head>"
          + FileUtils.LINE_SEP + "<body><P>");
      fileOutput.write("This page contains of "); // var
      fileOutput.write(String.valueOf(frameList.getLength()));
      fileOutput.write(" frames."); // var
      fileOutput.write("<br>" + FileUtils.LINE_SEP);
      fileOutput.write("Please select one of them."); // var
      fileOutput.write("</P>" + FileUtils.LINE_SEP + "<ol>"
          + FileUtils.LINE_SEP);

      String strTitle, strName;
      for (int i = 0; i < frameList.getLength(); i++) {
        Element frameEl = (Element) frameList.item(i);
        strTitle = frameEl.getAttribute("title");
        strName = frameEl.getAttribute("name");
        if (strTitle.equals(""))
          strTitle.equals("none");
        if (strName.equals(""))
          strName.equals("none");
        fileOutput.write("<li><a href=\"" + frameEl.getAttribute("src")
            + "\">Title: \"" + strTitle + "\".<BR> Name: \""
            + strName + "\".<BR> src: \""
            + frameEl.getAttribute("src") + "\".</a>"
            + FileUtils.LINE_SEP);
      }
      fileOutput.write("</ol></body></html>");
      fileOutput.flush();
      fileOutput.close();

      webBrowser.navigate(sFileName);
      return true;
    } else {
      return false;
    }
  }

  private String createUUID() {
    String prefix = null;
    // ユニークIDの一意性をチェックする
    for(int i = 0; i < 10; i++) {
      prefix = UUID.randomUUID().toString();
      File test = new File(tmpDirS, prefix + ORIG_HTML_FILE);
      if (!test.exists()) {
        break;
      } else {
        prefix = null;
      }
    }
    return prefix;
  }

  private void cleanTmpfiles() {
    File[] files = {
        getResultFile(),
        new File(tmpDirS, orgFileName),
        new File(tmpDirS, ieFileName),
        new File(tmpDirS, sourceFileName),
        new File(tmpDirS, targetFileName)
    };

    for (File f : files) {
      if (f.exists()) {
        f.delete();
      }
    }
  }
}
