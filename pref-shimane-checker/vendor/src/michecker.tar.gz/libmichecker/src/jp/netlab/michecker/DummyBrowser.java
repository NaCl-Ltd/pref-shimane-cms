package jp.netlab.michecker;
/*******************************************************************************
 * Copyright (c) 2011 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import org.eclipse.actf.model.ui.editor.browser.IWebBrowserACTF;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class DummyBrowser implements IWebBrowserACTF {

  private String html;

  public String[] getSupportMIMETypes() {
    // TODO Auto-generated method stub
    return null;
  }

  public String[] getSupportExtensions() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getCurrentMIMEType() {
    // TODO Auto-generated method stub
    return null;
  }

  public void open(String html) {
    this.html = html;
  }

  public void open(File target) {

  }

  public String getURL() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getTitle() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getID() {
    // TODO Auto-generated method stub
    return null;
  }

  public Document getDocument() {
    // TODO Auto-generated method stub
    return null;
  }

  public Document getLiveDocument() {
    // TODO Auto-generated method stub
    return null;
  }

  public File saveOriginalDocument(String file) {
    OutputStream os = null;
    Writer w = null;
    BufferedWriter bw = null;
    try {
      os = new FileOutputStream(file);
      w  = new OutputStreamWriter(os, "UTF-8");
      bw = new BufferedWriter(w);
      bw.write(html);
    } catch (Exception e) {
      throw new RuntimeException(e);
    } finally {
      if (bw != null) try { bw.close(); } catch (IOException e) {}
      if (w  != null) try { w .close(); } catch (IOException e) {}
      if (os != null) try { os.close(); } catch (IOException e) {}
    }
    return null;
  }

  public File saveDocumentAsHTMLFile(String file) {
    OutputStream os = null;
    Writer w = null;
    BufferedWriter bw = null;
    try {
      os = new FileOutputStream(file);
      w  = new OutputStreamWriter(os, "UTF-8");
      bw = new BufferedWriter(w);
      bw.write(html);
    } catch (Exception e) {
      throw new RuntimeException(e);
    } finally {
      if (bw != null) try { bw.close(); } catch (IOException e) {}
      if (w  != null) try { w .close(); } catch (IOException e) {}
      if (os != null) try { os.close(); } catch (IOException e) {}
    }
    return null;
  }

  public void jumpToNode(Node target) {
    // TODO Auto-generated method stub

  }


  public Object getAttribute(String key) {
    // TODO Auto-generated method stub
    return null;
  }

  public void setFocusAddressText(boolean selectAll) {
    // TODO Auto-generated method stub

  }

  public void showAddressText(boolean flag) {
    // TODO Auto-generated method stub

  }

  public void navigate(String url) {
    // TODO
    // InputStream is;
    // URL url = new java.net.URL(url);
    // is = url.openStream();

  }

  public void goBackward() {
    // TODO Auto-generated method stub

  }

  public void goForward() {
    // TODO Auto-generated method stub

  }

  public void navigateStop() {
    // TODO Auto-generated method stub

  }

  public void navigateRefresh() {
    // TODO Auto-generated method stub

  }

  public int getReadyState() {
    // TODO Auto-generated method stub
    return 0;
  }

  public boolean isReady() {
    // TODO Auto-generated method stub
    return false;
  }

  public String getLocationName() {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean isUrlExists() {
    return true;
  }

  public int getNavigateErrorCode() {
    // TODO Auto-generated method stub
    return 0;
  }

  public void setWebBrowserSilent(boolean bSilent) {
    // TODO Auto-generated method stub

  }

  public void setDisableScriptDebugger(boolean bDisable) {
    // TODO Auto-generated method stub

  }

  public boolean isDisableScriptDebugger() {
    // TODO Auto-generated method stub
    return false;
  }

  public void highlightElementById(String id) {
    // TODO Auto-generated method stub

  }

  public void hightlightElementByAttribute(String name, String value) {
    // TODO Auto-generated method stub

  }

  public void clearHighlight() {
    // TODO Auto-generated method stub

  }

  public void setFontSize(int fontSize) {
    // TODO Auto-generated method stub

  }

  public int getFontSize() {
    // TODO Auto-generated method stub
    return 0;
  }

  public int getBrowserAddress() {
    // TODO Auto-generated method stub
    return 0;
  }

  public int setTimeout(String script, int interval) {
    // TODO Auto-generated method stub
    return 0;
  }

  public boolean clearTimeout(int id) {
    // TODO Auto-generated method stub
    return false;
  }

  public int setInterval(String script, int interval) {
    // TODO Auto-generated method stub
    return 0;
  }

  public boolean clearInterval(int id) {
    // TODO Auto-generated method stub
    return false;
  }

}
