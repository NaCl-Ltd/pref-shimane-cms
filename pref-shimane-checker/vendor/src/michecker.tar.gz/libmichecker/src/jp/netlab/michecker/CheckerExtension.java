package jp.netlab.michecker;

import org.eclipse.actf.examples.adesigner.eval.html.Checker;
import org.eclipse.actf.examples.adesigner.eval.html.HtmlCheckerInfoProvider;
import org.eclipse.actf.visualization.eval.IChecker;
import org.eclipse.actf.visualization.eval.ICheckerInfoProvider;

public class CheckerExtension {
  private static IChecker[] checkers = null;

  private static ICheckerInfoProvider[] infoProviders = null;

  public static IChecker[] getCheckers() {
    if (checkers == null) {
      checkers = new IChecker[1];
      checkers[0] = new Checker();
    }
    return checkers;
  }

  public static ICheckerInfoProvider[] getCheckerInfoProviders() {
    if (infoProviders == null) {
      infoProviders = new ICheckerInfoProvider[1];
      infoProviders[0] = new HtmlCheckerInfoProvider();
    }
    return infoProviders;
  }
}
