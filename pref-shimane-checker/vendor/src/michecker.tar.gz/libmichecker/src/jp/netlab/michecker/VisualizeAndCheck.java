package jp.netlab.michecker;
/*******************************************************************************
 * Copyright (c) 2011 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/


import java.util.ArrayList;
import java.util.HashMap;

import org.eclipse.actf.model.internal.dom.html.impl.SHElement;
import org.eclipse.actf.visualization.blind.IBlindVisualizer;
import org.eclipse.actf.visualization.engines.blind.eval.EvaluationResultBlind;
import org.eclipse.actf.visualization.engines.blind.eval.PageEvaluation;
import org.eclipse.actf.visualization.eval.IEvaluationItem;
import org.eclipse.actf.visualization.eval.IEvaluationResult;
import org.eclipse.actf.visualization.eval.guideline.GuidelineHolder;
import org.eclipse.actf.visualization.eval.guideline.IGuidelineData;
import org.eclipse.actf.visualization.eval.html.statistics.PageData;
import org.eclipse.actf.visualization.eval.problem.HighlightTargetNodeInfo;
import org.eclipse.actf.visualization.eval.problem.HighlightTargetSourceInfo;
import org.eclipse.actf.visualization.eval.problem.IProblemItem;
import org.w3c.dom.Node;

import com.fasterxml.jackson.databind.ObjectMapper;

public class VisualizeAndCheck {
  private DummyBrowser browser = new DummyBrowser();
  private IBlindVisualizer visualizer = null;

  /**
   * コンストラクタ
   *
   * @param tmpDirs 一時ファイルの保管場所
   */
  public VisualizeAndCheck(String tmpDirs) {
    BlindVisualizerHtml blindVisualizerHtml = new BlindVisualizerHtml(tmpDirs);
    visualizer = blindVisualizerHtml;
  }

  public String doEvaluate(String html) {
    browser.open(html);
    return doEvaluate();
  }

  private String doEvaluate() {
    String ret = null;
    ArrayList<HashMap<String, Object>> problems = new ArrayList<HashMap<String, Object>>();

    visualizer.setModelService(browser);

    int result = visualizer.visualize();
    if (result == IBlindVisualizer.ERROR) {
      return null;
    }

    IEvaluationResult report = visualizer.getEvaluationResult();
    PageData _pageData = visualizer.getPageData();

    // Evaluate target page by using statistics data (PageData) and
    // evaluation results (list of IProblemItem).
    PageEvaluation _pageEval = new PageEvaluation(report.getProblemList(), _pageData);

    if (report instanceof EvaluationResultBlind) {
      EvaluationResultBlind erb = (EvaluationResultBlind) report;
      erb.setPageEvaluation(_pageEval);
      PageEvaluation pageEval = erb.getPageEvaluation();

      /*
       * PageData includes several statistics data, such as number of
       * images in the page, etc. Please see
       * org.eclipse.actf.visualization.eval.html.statistics.PageData for
       * more details.
       */
      @SuppressWarnings("unused")
      PageData pageData = null;
      if (pageEval != null) {
        /*
         * If you need to store evaluation scores, please use these
         * data.
         */
//        overallRating = pageEval.getOverallRating();
//        evaluationMetrics = pageEval.getMetrics();
//        evaluationScores = pageEval.getScores();
//
//        System.out.println(overallRating);
//        for (int i = 0; i < evaluationMetrics.length; i++) {
//          System.out.println(evaluationMetrics[i] + " : "
//              + evaluationScores[i]);
//        }

        // statistics data
        pageData = pageEval.getPageData();
      }

      GuidelineHolder gh = GuidelineHolder.getInstance();
      String[] metricsNames = gh.getLocalizedMetricsNames();
      String[] guidelineNames = gh.getGuidelineNames();
      boolean[] enabledMetrics = gh.getEnabledMetrics();
      boolean[] enabledGuidelines = new boolean[guidelineNames.length];
      IGuidelineData tmpGD[] = gh.getGuidelineData();
      for (int i = 0; i < tmpGD.length; i++) {
        enabledGuidelines[i] = tmpGD[i].isEnabled();
      }

      for(IProblemItem item: erb.getProblemList()) {
        HashMap<String, Object> h = new HashMap<String, Object>();
        HashMap<String, String> scores = new HashMap<String, String>();
        HashMap<String, String> guidelines = new HashMap<String, String>();
        ArrayList<HashMap<String, String>> tags = new ArrayList<HashMap<String, String>>();

        IEvaluationItem evalItem = item.getEvaluationItem();
        int[] metricsValues = evalItem.getMetricsScores();
        for (int i = 0; i < metricsValues.length; i++) {
          if (enabledMetrics[i]) {
            scores.put(metricsNames[i], Integer.toString(-metricsValues[i]));
          }
        }
        String[] guidelineValues = evalItem.getTableDataGuideline();
        for (int i = 0; i < guidelineValues.length; i++) {
          if (enabledGuidelines[i]) {
            guidelines.put(guidelineNames[i], guidelineValues[i]);
          }
        }

        String description = item.getDescription();
        String target = item.getTargetString();

        try {
          if (description != null && description.length() > 0) {
            h.put("description", new String(description.getBytes("UTF-8"), "UTF-8"));
          }

          if (target != null && target.length() > 0) {
            h.put("target", new String(target.getBytes("UTF-8"), "UTF-8"));
          }
        } catch(Exception ex) {
          ;
        }
        h.put("id", item.getEvaluationItem().getId());
        h.put("severity", item.getSeverity());
        h.put("scores", scores);
        h.put("guidelines", guidelines);

        Node targetNode = item.getTargetNode();
        if (targetNode != null) {
          HashMap<String, String> tag = new HashMap<String, String>();
          tag.put("line", item.getLineStr());
          tag.put("name",  targetNode.getNodeName());
//          tag.put("name",  ((SHElement)targetNode).getTagName());
          tags.add(tag);
          h.put("tags", tags);
        } else {
          HighlightTargetSourceInfo[] sourceInfos = item.getHighlightTargetSoruceInfo();
          HighlightTargetNodeInfo nodeInfo = item.getHighlightTargetNodeInfo();

          if (nodeInfo != null && nodeInfo.getTargets() != null && sourceInfos != null) {
            Node[] node = nodeInfo.getTargets();

            for (int i = 0; i < sourceInfos.length; i++) {
              HashMap<String, String> tag = new HashMap<String, String>();
              tag.put("line", String.valueOf(sourceInfos[i].getStartLine()));
              tag.put("name", ((SHElement)node[i]).getTagName());
              tags.add(tag);
            }
            h.put("tags", tags);
          }
        }
        problems.add(h);
      };
    }

    try
    {
        ObjectMapper mapper = new ObjectMapper();
        ret = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(problems);
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    return ret;
  }
}
