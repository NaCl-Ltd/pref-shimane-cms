/*******************************************************************************
 * Copyright (c) 2003, 2008 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/
package org.eclipse.actf.visualization.internal.eval;

import java.util.ResourceBundle;

public final class Messages {

  private static final String BUNDLE_NAME = "org.eclipse.actf.visualization.internal.eval.messages";//$NON-NLS-1$

  private Messages() {
    // Do not instantiate
  }

  public static String ProblemConst_All_Errors_1;
  public static String ProblemConst_Warning;
  public static String ProblemConst_Essential_2;
  public static String ProblemConst_Advanced_3;
  public static String ProblemConst_Basic_4;
  public static String ProblemConst_User_Check_5;
  public static String ProblemConst_Compliance_6;
  public static String ProblemConst_Trash_7;
  public static String ProblemConst_Type_11;
  public static String ProblemConst_Line_12;
  public static String ProblemConst_Highlight;
  public static String ProblemConst_Problem_Description_17;
  public static String ProblemConst_Foreground_18;
  public static String ProblemConst_Background_19;
  public static String ProblemConst_Severity_20;
  public static String ProblemConst_X_21;
  public static String ProblemConst_Y_22;
  public static String ProblemConst_0;
  public static String ProblemConst_Area_23;
  public static String ProblemConst_Detailed_report;
  public static String ProblemConst_Summary_report;
  public static String ProblemConst_Info;
  public static String NavigabilityWarningDialog_Message1;
  public static String NavigabilityWarningDialog_Message2;
  public static String NavigabilityWarningDialog_EnableWCAG;
  public static String NavigabilityWarningDialog_DisableNav;
  public static String NavigabilityWarningDialog_Continue;
  public static String adesigner_preference_guideline_list_group_text;
  public static String adesigner_preference_guideline_criteria_group_text;
  public static String adesigner_preference_guideline_properties_group_text;
  public static String DialogCheckerOption_Line_Number_Information_19;
  public static String DialogCheckerOption_Add_line_number_20;
  public static String DialogCheckerOption_LIVE_DOM;
  public static String GuidelinePreferencePage_0;
  public static String GuidelinePreferencePage_1;
  public static String Techniques;
  public static String Type;
  public static String Help;
  public static String Perceivable;
  public static String Operable;
  public static String Understandable;
  public static String Robust;

  static {
    ResourceBundle rb = ResourceBundle.getBundle(BUNDLE_NAME);
    ProblemConst_All_Errors_1 = rb.getString("ProblemConst_All_Errors_1");
    ProblemConst_Warning = rb.getString("ProblemConst_Warning");
    ProblemConst_Essential_2= rb.getString("ProblemConst_Essential_2");
    ProblemConst_Advanced_3 = rb.getString("ProblemConst_Advanced_3");
    ProblemConst_Basic_4 = rb.getString("ProblemConst_Basic_4");
    ProblemConst_User_Check_5 = rb.getString("ProblemConst_User_Check_5");
    ProblemConst_Compliance_6 = rb.getString("ProblemConst_Compliance_6");
    ProblemConst_Trash_7 = rb.getString("ProblemConst_Trash_7");
    ProblemConst_Type_11 = rb.getString("ProblemConst_Type_11");
    ProblemConst_Line_12 = rb.getString("ProblemConst_Line_12");
    ProblemConst_Highlight = rb.getString("ProblemConst_Highlight");
    ProblemConst_Problem_Description_17 = rb.getString("ProblemConst_Problem_Description_17");
    ProblemConst_Foreground_18 = rb.getString("ProblemConst_Foreground_18");
    ProblemConst_Background_19 = rb.getString("ProblemConst_Background_19");
    ProblemConst_Severity_20 = rb.getString("ProblemConst_Severity_20");
    ProblemConst_X_21 = rb.getString("ProblemConst_X_21");
    ProblemConst_Y_22 = rb.getString("ProblemConst_Y_22");
    ProblemConst_0 = rb.getString("ProblemConst_0");
    ProblemConst_Area_23 = rb.getString("ProblemConst_Area_23");
    ProblemConst_Detailed_report = rb.getString("ProblemConst_Detailed_report");
    ProblemConst_Summary_report = rb.getString("ProblemConst_Summary_report");
    ProblemConst_Info = rb.getString("ProblemConst_Info");
    NavigabilityWarningDialog_Message1 = rb.getString("NavigabilityWarningDialog_Message1");
    NavigabilityWarningDialog_Message2 = rb.getString("NavigabilityWarningDialog_Message2");
    NavigabilityWarningDialog_EnableWCAG = rb.getString("NavigabilityWarningDialog_EnableWCAG");
    NavigabilityWarningDialog_DisableNav = rb.getString("NavigabilityWarningDialog_DisableNav");
    NavigabilityWarningDialog_Continue = rb.getString("NavigabilityWarningDialog_Continue");
    adesigner_preference_guideline_list_group_text = rb.getString("adesigner_preference_guideline_list_group_text");
    adesigner_preference_guideline_criteria_group_text = rb.getString("adesigner_preference_guideline_criteria_group_text");
    adesigner_preference_guideline_properties_group_text = rb.getString("adesigner_preference_guideline_properties_group_text");
    DialogCheckerOption_Line_Number_Information_19 = rb.getString("DialogCheckerOption_Line_Number_Information_19");
    DialogCheckerOption_Add_line_number_20 = rb.getString("DialogCheckerOption_Add_line_number_20");
    DialogCheckerOption_LIVE_DOM = rb.getString("DialogCheckerOption_LIVE_DOM");
    GuidelinePreferencePage_0 = rb.getString("GuidelinePreferencePage_0");
    GuidelinePreferencePage_1 = rb.getString("GuidelinePreferencePage_1");
    Techniques = rb.getString("Techniques");
    Type = rb.getString("Type");
    Help = rb.getString("Help");
    Perceivable = rb.getString("Perceivable");
    Operable = rb.getString("Operable");
    Understandable = rb.getString("Understandable");
    Robust = rb.getString("Robust");
  }
}