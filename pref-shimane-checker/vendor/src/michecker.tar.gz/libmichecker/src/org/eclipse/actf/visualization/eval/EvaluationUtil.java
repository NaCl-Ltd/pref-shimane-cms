package org.eclipse.actf.visualization.eval;

import jp.netlab.michecker.CheckerExtension;

/**
 * Utility class for org.eclipse.actf.visualization.eval plugin
 */
public class EvaluationUtil {

    /**
     * The plug-in ID
     */
    public static final String PLUGIN_ID = "org.eclipse.actf.visualization.eval"; //$NON-NLS-1$

    /**
     * Check user selection of target DOM (original source or live)
     *
     * @return true, if user selected original DOM in preference page
     */
    public static boolean isOriginalDOM() {
        return true;
    }

    /**
     * Get all registered {@link IChecker}
     *
     * @return array of {@link IChecker}
     */
    public static IChecker[] getCheckers() {
        return CheckerExtension.getCheckers();
    }

    /**
     * Get all registered {@link ICheckerInfoProvider}
     *
     * @return array of {@link ICheckerInfoProvider}
     */
    public static ICheckerInfoProvider[] getCheckerInfoProviders() {
        return CheckerExtension.getCheckerInfoProviders();
    }
}
