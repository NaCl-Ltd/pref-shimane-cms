/*******************************************************************************
 * Copyright (c) 2006, 2008 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/
package org.eclipse.actf.visualization.internal.engines.blind;

import java.util.ResourceBundle;

public final class Messages {

  private static final String BUNDLE_NAME = "org.eclipse.actf.visualization.internal.engines.blind.messages";//$NON-NLS-1$

  private Messages() {
    // Do not instantiate
  }

  public static String AltDialog_TITLE;
  public static String AltDialog_Column_Name;
  public static String AltDialog_MSG_No_String;
  public static String AltDialog_MSG_Existed;
  public static String PageEvaluation_Bad;
  public static String PageEvaluation_Excellent;
  public static String PageEvaluation_Good;
  public static String PageEvaluation_Poor;
  public static String Eval_redundant_img_alt;
  public static String Eval_wrong_img_alt;
  public static String Eval_no_img_alt;
  public static String Eval_redundant_img_alt_error_msg;
  public static String Eval_wrong_img_alt_error_msg;
  public static String Eval_no_img_alt_error_msg;
  public static String Eval_navigability_low_score_error_msg;
  public static String Eval_navigability_long_time_error_msg;
  public static String Eval_navigability_good_msg;
  public static String Eval_confirm_errors_detailed_report;
  public static String Eval_confirm_alt_attributes_first;
  public static String Eval_many_accessibility_issues;
  public static String Eval_some_accessibility_issues;
  public static String Eval_completely_compliant_with_user_check_items;
  public static String Eval_completely_compliant;
  public static String Eval_some_errors_on_metrics;
  public static String Eval_some_errors_on_metrics1;
  public static String Eval_user_check1;
  public static String Eval_user_check2;
  public static String Eval_compliant_with_some_other_errors;
  public static String Eval_excellent;
  public static String Eval_easy_for_blind_user_to_navigate;
  public static String Eval_page_has_skiplinks_headings;
  public static String Eval_darkcolored_visualization_view;
  public static String DialogSettingBlind_NG_Word___Wrong_Text_5;
  public static String DialogSettingBlind_NG_Word_Wrong_Text_Edit____25;
  public static String DialogSettingBlind_Language_4;
  public static String DialogSettingBlind_English_15;
  public static String DialogSettingBlind_Japanese_16;
  public static String DialogSettingBlind_SimpliedChinese_17;
  public static String DialogSettingBlind_LayoutModeSetting;
  public static String DialogSettingBlind_Visualization_mode_3;
  public static String DialogSettingBlind_Voice_browser_output_mode_8;
  public static String DialogSettingBlind_Layout_mode_9;
  public static String DialogSettingBlind_Maximum_time_17;
  public static String DialogSettingBlind_Color_for_maximum_time_19;
  public static String DialogSettingBlind_Table_headers_20;
  public static String DialogSettingBlind_Heading_tags_21;
  public static String DialogSettingBlind_Input_tags_22;
  public static String DialogSettingBlind_Label_tags_23;
  public static String DialogSettingBlind_Tabel_border_24;

  public static String VisualizeBrowserMode;
  public static String VisualizeBrowserModeTooltip;

  static {
    ResourceBundle rb = ResourceBundle.getBundle(BUNDLE_NAME);
    AltDialog_TITLE =  rb.getString("AltDialog_TITLE");
    AltDialog_Column_Name = rb.getString("AltDialog_Column_Name");
    AltDialog_MSG_No_String= rb.getString("AltDialog_MSG_No_String");
    AltDialog_MSG_Existed= rb.getString("AltDialog_MSG_Existed");
    PageEvaluation_Bad= rb.getString("PageEvaluation_Bad");
    PageEvaluation_Excellent= rb.getString("PageEvaluation_Excellent");
    PageEvaluation_Good= rb.getString("PageEvaluation_Good");
    PageEvaluation_Poor= rb.getString("PageEvaluation_Poor");
    Eval_redundant_img_alt= rb.getString("Eval_redundant_img_alt");
    Eval_wrong_img_alt = rb.getString("Eval_wrong_img_alt");
    Eval_no_img_alt = rb.getString("Eval_no_img_alt");
    Eval_redundant_img_alt_error_msg = rb.getString("Eval_redundant_img_alt_error_msg");
    Eval_wrong_img_alt_error_msg = rb.getString("Eval_wrong_img_alt_error_msg");
    Eval_no_img_alt_error_msg = rb.getString("Eval_no_img_alt_error_msg");
    Eval_navigability_low_score_error_msg = rb.getString("Eval_navigability_low_score_error_msg");
    Eval_navigability_long_time_error_msg = rb.getString("Eval_navigability_long_time_error_msg");
    Eval_navigability_good_msg = rb.getString("Eval_navigability_good_msg");
    Eval_confirm_errors_detailed_report = rb.getString("Eval_confirm_errors_detailed_report");
    Eval_confirm_alt_attributes_first = rb.getString("Eval_confirm_alt_attributes_first");
    Eval_many_accessibility_issues = rb.getString("Eval_many_accessibility_issues");
    Eval_some_accessibility_issues = rb.getString("Eval_some_accessibility_issues");
    Eval_completely_compliant_with_user_check_items = rb.getString("Eval_completely_compliant_with_user_check_items");
    Eval_completely_compliant = rb.getString("Eval_completely_compliant");
    Eval_some_errors_on_metrics = rb.getString("Eval_some_errors_on_metrics");
    Eval_some_errors_on_metrics1 = rb.getString("Eval_some_errors_on_metrics1");
    Eval_user_check1 = rb.getString("Eval_user_check1");
    Eval_user_check2 = rb.getString("Eval_user_check2");
    Eval_compliant_with_some_other_errors = rb.getString("Eval_compliant_with_some_other_errors");
    Eval_excellent = rb.getString("Eval_excellent");
    Eval_easy_for_blind_user_to_navigate = rb.getString("Eval_easy_for_blind_user_to_navigate");
    Eval_page_has_skiplinks_headings = rb.getString("Eval_page_has_skiplinks_headings");
    Eval_darkcolored_visualization_view = rb.getString("Eval_darkcolored_visualization_view");
    DialogSettingBlind_NG_Word___Wrong_Text_5 = rb.getString("DialogSettingBlind_NG_Word___Wrong_Text_5");
    DialogSettingBlind_NG_Word_Wrong_Text_Edit____25 = rb.getString("DialogSettingBlind_NG_Word_Wrong_Text_Edit____25");
    DialogSettingBlind_Language_4 = rb.getString("DialogSettingBlind_Language_4");
    DialogSettingBlind_English_15 = rb.getString("DialogSettingBlind_English_15");
    DialogSettingBlind_Japanese_16 = rb.getString("DialogSettingBlind_Japanese_16");
    DialogSettingBlind_SimpliedChinese_17 = rb.getString("DialogSettingBlind_SimpliedChinese_17");
    DialogSettingBlind_LayoutModeSetting = rb.getString("DialogSettingBlind_LayoutModeSetting");
    DialogSettingBlind_Visualization_mode_3 = rb.getString("DialogSettingBlind_Visualization_mode_3");
    DialogSettingBlind_Voice_browser_output_mode_8 = rb.getString("DialogSettingBlind_Voice_browser_output_mode_8");
    DialogSettingBlind_Layout_mode_9 = rb.getString("DialogSettingBlind_Layout_mode_9");
    DialogSettingBlind_Maximum_time_17 = rb.getString("DialogSettingBlind_Maximum_time_17");
    DialogSettingBlind_Color_for_maximum_time_19 = rb.getString("DialogSettingBlind_Color_for_maximum_time_19");
    DialogSettingBlind_Table_headers_20 = rb.getString("DialogSettingBlind_Table_headers_20");
    DialogSettingBlind_Heading_tags_21 = rb.getString("DialogSettingBlind_Heading_tags_21");
    DialogSettingBlind_Input_tags_22 = rb.getString("DialogSettingBlind_Input_tags_22");
    DialogSettingBlind_Label_tags_23 = rb.getString("DialogSettingBlind_Label_tags_23");
    DialogSettingBlind_Tabel_border_24 = rb.getString("DialogSettingBlind_Tabel_border_24");
    VisualizeBrowserMode = rb.getString("VisualizeBrowserMode");
    VisualizeBrowserModeTooltip = rb.getString("VisualizeBrowserModeTooltip");

  }
}