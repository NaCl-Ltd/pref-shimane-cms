/*******************************************************************************
 * Copyright (c) 2006, 2008 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/
package org.eclipse.actf.visualization.internal.engines.blind.html;

import java.util.ResourceBundle;

public final class Messages {

  private static final String BUNDLE_NAME = "org.eclipse.actf.visualization.internal.engines.blind.html.messages";//$NON-NLS-1$

  private Messages() {
    // Do not instantiate
  }

  public static String BlindView_Open_ID;
  public static String CSSViewer_0;
  public static String CSSViewer_1;
  public static String ElementViewerJFace_0;
  public static String ElementViewerJFace_1;

  static {
    ResourceBundle rb = ResourceBundle.getBundle(BUNDLE_NAME);
    BlindView_Open_ID =  rb.getString("BlindView_Open_ID");
    CSSViewer_0 =  rb.getString("CSSViewer_0");
    CSSViewer_1 =  rb.getString("CSSViewer_1");
    ElementViewerJFace_0 =  rb.getString("ElementViewerJFace_0");
    ElementViewerJFace_1 =  rb.getString("ElementViewerJFace_1");
  }
}