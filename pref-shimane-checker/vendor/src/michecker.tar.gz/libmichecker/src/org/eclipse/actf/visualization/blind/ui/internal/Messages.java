/*******************************************************************************
 * Copyright (c) 2006, 2008 IBM Corporation and Others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Kentarou FUKUDA - initial API and implementation
 *******************************************************************************/
package org.eclipse.actf.visualization.blind.ui.internal;

import java.util.ResourceBundle;

public final class Messages {

	private static final String BUNDLE_NAME = "org.eclipse.actf.visualization.blind.ui.internal.messages";//$NON-NLS-1$

	private Messages() {
		// Do not instantiate
	}

	public static String BlindView_Maximum_Time;
	public static String BlindView_Done;
	public static String BlindView_Now_preparing;
	public static String BlindView_Now_processing;
	public static String BlindView_Now_rendering;
	public static String BlindView_saving_file;
	public static String BlindView_end_saving_file;
	public static String BlindView_Visualize_4;
	public static String BlindVisualizationAction_0;
	public static String Visualization_Error;
	public static String Report;

	static {
	    ResourceBundle rb = ResourceBundle.getBundle(BUNDLE_NAME);
	    BlindView_Maximum_Time     = rb.getString("BlindView_Maximum_Time");
	    BlindView_Done             = rb.getString("BlindView_Done");
	    BlindView_Now_preparing    = rb.getString("BlindView_Now_preparing");
	    BlindView_Now_processing   = rb.getString("BlindView_Now_processing");
	    BlindView_Now_rendering    = rb.getString("BlindView_Now_rendering");
	    BlindView_saving_file      = rb.getString("BlindView_saving_file");
	    BlindView_end_saving_file  = rb.getString("BlindView_end_saving_file");
	    BlindView_Visualize_4      = rb.getString("BlindView_Visualize_4");
	    BlindVisualizationAction_0 = rb.getString("BlindVisualizationAction_0");
	    Visualization_Error        = rb.getString("Visualization_Error");
	    Report                     = rb.getString("Report");

	}
}